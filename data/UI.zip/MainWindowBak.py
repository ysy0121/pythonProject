# -*- coding: utf-8 -*-
import os
import sys
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import QtWidgets
from PyQt5 import uic
import socket
from _thread import *

CWD = str(os.getcwd())
# print(CWD)

formMain = uic.loadUiType("MainWindow.ui")[0]


class DialogWindow(QDialog):
    SERVER_IP = ''
    SERVER_PORT = ''
    PRT = None
    SERVER_SOCKET = None
    SERVER_FLAG = True

    def __init__(self, parent):
        super(DialogWindow, self).__init__(parent)
        self.PRT = parent
        ui = 'DialogWindow.ui'
        uic.loadUi(ui, self)
        self.setServerInfo()
        self.buttonUi()
        self.show()
        # print(parent.txt_ip.text())

    def setServerInfo(self):
        self.SERVER_IP = self.PRT.txt_ip.text()
        self.SERVER_PORT = self.PRT.txt_port.text()
        print(self.SERVER_IP + ":" + self.SERVER_PORT)

    def textWrite(self, text):
        self.textedit.appendPlainText(text)

    def conn_thread(self, client_socket, addr):
        self.textWrite('Connected by : ' + str(addr[0]) + ', ' + str(addr[1]))

        while self.SERVER_FLAG:
            try:
                data = client_socket.recv(1024)
                self.textWrite('Received from ' + str(addr[0]) + ', ' + str(addr[1]) + ', ' + data.decode())
                client_socket.sendall(data)

                if data == 'Quit':
                    self.textWrite('Disconnected by ' + str(addr[0]) + ', ' + str(addr[1]))
                    break

            except ConnectionResetError as e:
                self.textWrite('Disconnected by ' + str(addr[0]) + ', ' + str(addr[1]))
                break

        client_socket.close()
        self.textWrite('######### Client Disconnected')

    def serverStart(self):
        self.setServerInfo()
        self.textWrite('######### server info-' + self.SERVER_IP + ':' + self.SERVER_PORT)

        self.SERVER_SOCKET = socket.socket(socket.AF_INET, socket.SOCK_STREAM);
        self.SERVER_SOCKET.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.SERVER_SOCKET.bind((self.SERVER_IP, int(self.SERVER_PORT)))
        self.SERVER_SOCKET.listen()

        self.textWrite('######### server start...')

        while self.SERVER_FLAG:
            self.textWrite('######### client waiting...')
            client_socket, addr = self.SERVER_SOCKET.accept()
            start_new_thread(self.conn_thread, (client_socket, addr))

        self.SERVER_SOCKET.close()
        self.textWrite('######### server stop...')

    def serverStop(self):
        self.SERVER_FLAG = False
        self.textWrite('######### stopping...')

    def buttonUi(self):
        self.btn_start.clicked.connect(self.serverStart)
        self.btn_stop.clicked.connect(self.serverStop)


class MainWindow(QMainWindow, formMain):

    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.buttonUi()
        self.initUI()

    def connectWindow(self):
        Dig = DialogWindow(self)
        self.btn_connect.setEnabled(False)
        Dig.exec_()
        self.chatWrite('connect active...')
        self.btn_connect.setEnabled(True)

    def chatWrite(self, text):
        self.chat_textedit.append(text)

    def chatWindow(self):
        self.chatWrite(self.chat_txt.text())
        self.chat_txt.setText('')

    def buttonUi(self):
        self.btn_connect.clicked.connect(self.connectWindow)
        self.chat_btn.clicked.connect(self.chatWindow)
        self.chat_txt.returnPressed.connect(self.chatWindow)

    def moveCenter(self):
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def initUI(self):
        self.setWindowTitle('Main System from Python')
        self.setWindowIcon(QIcon(CWD + '/web.png'))
        # self.setGeometry(300, 300, 300, 200)
        # self.move(300, 300)
        # self.resize(800, 600)
        self.moveCenter()
        self.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    mainwindow = MainWindow()
    mainwindow.show()
    sys.exit(app.exec_())
